/**************************************\
 * File Name:      main.c
 * Project Name:   EECS373 Final Project
 * Created by:     Adrian Padin
 * Start date:     15 March 2016
 * Last modified:  22 March 2016
\**************************************/

#include <stdio.h>
#include <inttypes.h>
#include <assert.h>
#include <stdlib.h>

#include "drivers/mss_spi/mss_spi.h"
#include "drivers/mss_uart/mss_uart.h"
#include "drivers/mss_gpio/mss_gpio.h"
#include "drivers/mss_ace/mss_ace.h"
#include "drivers/CoreUARTapb/core_uart_apb.h"
#include "ps2.h"
#include "arena.h"
#include "screenControl.h"
#include "light_show.h"
#include "linked_list.h"
#include "defines.h"

/********** GLOBAL VARIABLES **********/

// Global controller structs
controller_t controller1;
controller_t controller2;
controller_t controller3;
controller_t controller4;

team_struct_t teamMaize;
team_struct_t teamBlue;

uint32_t countdownCounter = 0; // In seconds



/********** FUNCTION DECLARATIONS **********/
void poll_delay(int);
void buttonWait();
void stopCars();
void initGameSystem();
void teamScored(int);
void startGame();
void runGame();
void endGame();



/********** INTERRUPT HANDLERS **********/

// UART RX Interrupt Handler
void xbee_receive_data( mss_uart_instance_t * this_uart ){

    uint8_t rx_buff[4]; // keep the data buffer aligned

    // Read in data from rx_buff
	int num_bytes = MSS_UART_get_rx( this_uart, rx_buff, 4 );

	// Transmission failed
	if (num_bytes != 4) {
		return;
	}

	int car_select = rx_buff[0];
	//int vibration = rx_buff[1];

	// Set the vibration value
	switch (car_select) {
		case 1: set_vibration(&controller1, 0xFF); break;
		case 2: set_vibration(&controller2, 0xFF); break;
		//case 3: set_vibration(&controller3, vibration, 100); break;
		//case 4: set_vibration(&controller4, vibration, 100); break;
		default: break;
	}
	
	//printf("Got some XBEE data: car %x, value %x\r\n", car_select, vibration);
}


// Send data to the cars (not an irq but may become one later)
void send_data_to_car(controller_t * controller) {
	// Data sent to cars
	uint8_t tx_buff[4] = { 	controller->select,
							flip(controller->slave_buffer[1]) & 0xfe,
							flip(controller->slave_buffer[3]) | 0x01,
							0 //flip(controller->slave_buffer[5])
	};

    MSS_UART_polled_tx(&g_mss_uart1, tx_buff, 4);
}


// Fabint handler to handle, say, interrupts from fabric to MSS
__attribute__ ((interrupt)) void Fabric_IRQHandler( void )
{
    // Get the interrupt status (which also clears the internal interrupt on our hardware)
    uint32_t status = ARENA_getInterruptStatus();
    printf("Interrupt status: %u\n\r", (unsigned int) status);

    // Check that it was really a timer interrupt
    if(status & 0x02) {
    	// Simply increment the timer
		countdownCounter--;

		// If time has run out, game is over
    	if(countdownCounter == 0) {
    		endGame(); // does not return
    	}

    	// Otherwise, output time ONLY
    	ARENA_outputTimeLeft(countdownCounter);
	}

    // If it was a button interrupt at all, there's an issue here (as not wired atm)
    //if(status & 0x01) {
    //}

    NVIC_ClearPendingIRQ( Fabric_IRQn );
}


/********** GAME CODE FUNCTIONS **********/

void poll_delay(int cycles) {
	int i;

	if (cycles == 0) {
		full_capture(&controller1);
		full_capture(&controller2);
		//full_capture(&controller3);
		//full_capture(&controller4);
		return;
	}
	controller1.counter += cycles;
	controller2.counter += cycles;
	controller3.counter += cycles;
	controller4.counter += cycles;

	for (i = 0; i < cycles; i++) {
		full_capture(&controller1);
		full_capture(&controller2);
		//full_capture(&controller3);
		//full_capture(&controller4);
	}
}

// Doesn't return until all 4 controllers press and hold X at the same time
void buttonWait() {

	printf("Before waiting for controllers\n\r");

	// Wait for all controllers to press and hold X
	while ( flip(controller1.slave_buffer[10]) < 10
			|| flip(controller2.slave_buffer[10]) < 10
			//|| flip(controller2.slave_buffer[10]) < 10
			//|| flip(controller2.slave_buffer[10]) < 10
			) {

		poll_delay(0); // poll controllers
	}

	printf("After waiting for controllers\n\r");
}


// Sends messages to tell cars to stop
void stopCars() {
	// Send all zeros to cars
	int car_id;
	uint8_t tx_buff[4] = {0, 128, 129, 0};

	for (car_id = 1; car_id < 4; ++car_id) {
		tx_buff[0] = car_id;
		MSS_UART_polled_tx(&g_mss_uart1, tx_buff, 4);
	}
}


// All necessary setup to begin the game
void initGameSystem() {

	/********** SETUP SCREEN AND XBEES **********/

	SCREENCONTROL_init();

	MSS_UART_init (
		&g_mss_uart1,
		MSS_UART_57600_BAUD,
		(MSS_UART_DATA_8_BITS | MSS_UART_NO_PARITY | MSS_UART_ONE_STOP_BIT)
	);

	// Interrupt handler for incoming XBee data
	MSS_UART_set_rx_handler
	(
		&g_mss_uart1,
		xbee_receive_data,
		MSS_UART_FIFO_FOUR_BYTES
	);


	/********** SETUP LIGHT SHOW **********/

	init_lights();

	/********** SETUP TEAMS **********/

	ACE_init();

	ARENA_initTeam(&teamMaize, "ADCDirectInput_4");
	ARENA_initTeam(&teamBlue, "ADCDirectInput_5");

	teamMaize.score = 0;
	teamBlue.score = 0;

	/********** SETUP CONTROLLERS **********/

	MSS_SPI_init( &g_mss_spi1 );

	controller_init(&controller1, MSS_SPI_SLAVE_1);
	controller_init(&controller2, MSS_SPI_SLAVE_2);
	controller_init(&controller3, MSS_SPI_SLAVE_3);
	controller_init(&controller4, MSS_SPI_SLAVE_4);

	setup_all(&controller1);
	setup_all(&controller2);
	setup_all(&controller3);
	setup_all(&controller4);

	/********** SETUP TIMER **********/

	countdownCounter = GAMELENGTH;
}


// Returns 0 if no team won yet, returns 1 if a team won
// teamScoredFlag = 1 if Maize scored, = 2 if Blue scored
void teamScored(int teamScoredFlag) {

	// Disable the timer interrupt
	NVIC_DisableIRQ(Fabric_IRQn);

	// Stop the cars; game should be paused at the moment!
	stopCars();

	// Check if a team won
	if(teamMaize.score+1 == SCOREMAX) {
		// Return 1 so caller knows  game is now technically over
		endGame();
	}
	else if(teamBlue.score+1 == SCOREMAX) {
		// Return 1 so caller knows  game is now technically over
		endGame();
	}
	// Else, a team simply scored...
	else {
		if(teamScoredFlag == BLUE) {
			teamBlue.score++;
		}
		else {
			teamMaize.score++;
		}

		// Simply output score to screen
		ARENA_outputScoreToScreen(&teamMaize, &teamBlue);

		// TODO: Output something to screen to tell users to reset cars and ball

		// Team's light show
		light_show(teamScoredFlag);
		printf("Waiting for ACK\r\n");
		while ((MSS_GPIO_get_inputs() & MSS_GPIO_8_MASK) != 0) { // wait for show to start
			poll_delay(0);
		}
		turn_off_lights();
		ARENA_closeBallRelease();

		// Vibrate all controllers on and off four times
		int i = 0;
		for (i = 0; i < 4; ++i) {
			set_vibration(&controller1, 0xff);
			set_vibration(&controller2, 0xff);
			//set_vibration(&controller3, 0xff);
			//set_vibration(&controller4, 0xff);

			poll_delay(100);
			printf("Vibrate\r\n");

			set_vibration(&controller1, 0);
			set_vibration(&controller2, 0);
			//set_vibration(&controller3, 0);
			//set_vibration(&controller4, 0);

			poll_delay(100);
		}

		// Wait for team's show to end
		printf("Waiting for ACK\r\n");
		while ((MSS_GPIO_get_inputs() & MSS_GPIO_8_MASK) != MSS_GPIO_8_MASK) { poll_delay(0); }

		startGame(); // Returns to runGame()
	}
}


void startGame() {

	// Make sure cars don't move
	stopCars();

	// Disable timer
	NVIC_DisableIRQ(Fabric_IRQn);

	//
	ARENA_closeBallRelease();

	// TODO: Output to screen to press buttons
	// "Press X to Start

	buttonWait();

	// Start game light show
	light_show(START);

	// wait for show to start
	printf("Waiting for ACK\r\n");
	while ((MSS_GPIO_get_inputs() & MSS_GPIO_8_MASK) != 0) { poll_delay(0); }

	turn_off_lights(); // Turn off lights

	ARENA_openBallRelease(); // Release the ball

	// Wait for show to stop
	while ((MSS_GPIO_get_inputs() & MSS_GPIO_8_MASK) != MSS_GPIO_8_MASK) { poll_delay(0); }

	ARENA_outputScoreToScreen(&teamMaize, &teamBlue);
	ARENA_outputTimeLeft(countdownCounter);

	// Re-enable the timer interrupt
	NVIC_EnableIRQ(Fabric_IRQn);
}

// Runs game, doesn't return until game is over or button is pressed to reset game (? for latter)
void runGame() {

	/********** LOOP **********/

	while(1) {

		/********** CAPTURE CONTROLLER DATA ********/
		poll_delay(0);

		//printf("Controller1: %d\r\n", (int) controller1.slave_buffer[10]);
		//printf("Controller2: %d\r\n", (int) controller2.slave_buffer[10]);
		//printf("Controller3: %d\r\n", (int) controller3.slave_buffer[10]);
		//printf("Controller4: %d\r\n", (int) controller4.slave_buffer[10]);

		/********** SEND DATA TO CARS ********/
		send_data_to_car(&controller1);
		send_data_to_car(&controller2);
		//send_data_to_car(&controller3);
		//send_data_to_car(&controller4);

		// Vibration data is updated automagically by interrupts

		/********** CHECK SCORING **********/
		if (ARENA_checkIfScored(&teamMaize)) {
			teamScored(MAIZE);
		}
		else if (ARENA_checkIfScored(&teamBlue)) {
			teamScored(BLUE);
		}

		// Debugging
		//if (controller1.slave_buffer[5] > 100 && controller1.slave_buffer[11] > 100) {
		//	teamScored(MAIZE);
		//}
		//if (controller1.slave_buffer[4] > 100 && controller1.slave_buffer[9] > 100) {
		//	teamScored(BLUE);
		//}

		/********** EGGIES!!! ***********/

		// EGGIE INITS ///
		//uint8_t light_show_end=1;
		//uint32_t gpio_inputs=0;


		/*	Current Easter Egg Codes:
			1.	Triangle -> Circle -> X -> Square -> Triangle
			2.	Right -> Down -> Left -> Up -> Right
			3.
			4.
		 */


		//uint8_t press_seq0[]= {8,9,10,11,8};
		//uint8_t press_seq1[]={4,7,5,6,4};
		//init_easter_eggie(press_seq0,0,5);
		//init_easter_eggie(press_seq1,1,5);
		//controller_t c_array[15];
		//for (int a=0; a<15; a++){
		//	c_array[a].state[0]=0;
		//	c_array[a].state[1]=
		//}

		//easter_eggie(&controller1);
		//easter_eggie(&controller2);
		//easter_eggie(&controller3);
		//easter_eggie(&controller4);

		//gpio_inputs = MSS_GPIO_get_inputs();

		//if(gpio_inputs == 0x10) { //GPIO 4??
		//	light_show_end=1;
		//}

		//else {
		//	light_show_end=0;
		//}
		/*while(list not empty && light_show_end
			keep popping off light shows
			and call light_show functions
			light show function gets called in pop
		*/
		//SET TO HIGH FOR DEBUGGING W/O UNO
		//light_show_end=1;
		//show_t * current = head;
		//while((current != NULL) && light_show_end){
		//	current=current->next;
		//	pop();
		//	play();
		//}
		///*
	}
}

// Outputs game over stuff and cleans up as necessary
void endGame() {

	// Disable the timer interrupts
	NVIC_DisableIRQ(Fabric_IRQn);

	// Stop the cars
	stopCars();

	// TODO: Output game over message on screen

	int whoWon = 0;

	if(teamBlue.score > teamMaize.score) {
		light_show(BLUE);
		whoWon = BLUE;
	}
	else if(teamMaize.score > teamBlue.score) {
		light_show(MAIZE);
		whoWon = MAIZE;
	}
	else {
		// Else tie, so don't need to change whoWon
	}

	ARENA_outputEndToScreen(whoWon);

	while(1) {} // Game is over, wait for reset
}

int main(){

	// Initialize necessary game systems
 	initGameSystem();

	// Setup game and wait till button is pressed to start game
	// TODO: start game output
	ARENA_outputStartToScreen();
	startGame();

	// Play the game
	runGame(); // Does not return!

    return(0);
}
