/**************************************\
 * File Name:      main.c
 * Project Name:   EECS373 Final Project
 * Created by:     Adrian Padin
 * Start date:     15 March 2016
 * Last modified:  22 March 2016
\**************************************/

#include <stdio.h>
#include <inttypes.h>
#include <assert.h>
#include <stdlib.h>

#include "drivers/mss_spi/mss_spi.h"
#include "drivers/mss_uart/mss_uart.h"
#include "drivers/mss_gpio/mss_gpio.h"
#include "drivers/mss_ace/mss_ace.h"
#include "drivers/CoreUARTapb/core_uart_apb.h"
#include "ps2.h"
//#include "arena.h"
//#include "screenControl.h"
#include "light_show.h"
#include "linked_list.h"
#include "defines.h"

/********** GLOBAL VARIABLES **********/

// Global controller structs
controller_t controller1;
controller_t controller2;
//controller_t controller3;
//controller_t controller4;

int counter = 0;


/********** INTERRUPT HANDLERS **********/

// UART RX Interrupt Handler
/*
void xbee_receive_data( mss_uart_instance_t * this_uart ){

    uint8_t rx_buff[4]; // keep the data buffer aligned

    // Read in data from rx_buff
	int num_bytes = MSS_UART_get_rx( this_uart, rx_buff, 4 );
	assert(num_bytes == 4);

	int car_select = rx_buff[0];
	int vibration = rx_buff[1];

	// Set the vibration value
	switch (car_select) {
		case 1: set_vibration(&controller1, vibration); break;
		case 2: set_vibration(&controller2, vibration); break;
		//case 3: set_vibration(&controller3, vibration, 100); break;
		//case 4: set_vibration(&controller4, vibration, 100); break;
		default: break;
	}
	
	counter = 0;
	printf("Got some XBEE data: car %x, value %x\r\n", car_select, vibration);
}
*/

// Send data to the cars (not an irq but may become one later)
void send_data_to_car(controller_t * controller) {
	
	// Data sent to cars
	uint8_t tx_buff[4] = { 	controller->select,
							flip(controller->slave_buffer[1]) & 0xFE,
							flip(controller->slave_buffer[3]) | 0x01,
							0 };

	// Debugging
	printf("sending: %x, %x, %x\r\n", tx_buff[0], tx_buff[1], tx_buff[2]);

    MSS_UART_polled_tx(&g_mss_uart1, tx_buff, 4);
}


int main() {

    /********** INITIALIZATION **********/

    int i = 0;

    /********** SETUP UART **********/

   // SCREENCONTROL_init();

    MSS_UART_init (
        &g_mss_uart1,
        MSS_UART_57600_BAUD,
        (MSS_UART_DATA_8_BITS | MSS_UART_NO_PARITY | MSS_UART_ONE_STOP_BIT)
    );

    /*
    // Interrupt handler for incoming XBee data
    MSS_UART_set_rx_handler
    (
        &g_mss_uart1,
        xbee_receive_data,
        MSS_UART_FIFO_FOUR_BYTES
    );
	*/

    /********** SETUP LIGHT SHOW **********/

 //   init_lights();


    /********** SETUP ACE/GOALS **********/

    //ACE_init();

    //team_struct_t teamMaize, teamBlue;

    //ARENA_initTeam(&teamMaize, "ADCDirectInput_4");
    //ARENA_initTeam(&teamBlue, "ADCDirectInput_5");
    //ARENA_outputScoreToScreen(&teamMaize, &teamBlue);


    /********** SETUP CONTROLLERS **********/

    MSS_SPI_init( &g_mss_spi1 );

    controller_init(&controller1, MSS_SPI_SLAVE_1);
    //controller_init(&controller2, MSS_SPI_SLAVE_2);
    //controller_init(&controller3, MSS_SPI_SLAVE_3);
    //controller_init(&controller4, MSS_SPI_SLAVE_4);

    setup_all(&controller1);
    //setup_all(&controller2);
    //setup_all(&controller3);
    //setup_all(&controller4);

	
    /********** LOOP **********/

    for (i = 0; 1; ++i) {

        /********** CAPTURE CONTROLLER DATA ********/
    	printf("Responses %d:\r\n", i);
        full_capture(&controller1);
        //full_capture(&controller2);
        //full_capture(&controller3);
        //full_capture(&controller4);


     //   printf("Controller1: %d\r\n", (int) controller1.slave_buffer[0]);
     //   printf("Controller2: %d\r\n", (int) controller2.slave_buffer[0]);

        //printf("\r\nResponses %d:\r\n", i);
        //for (j = 0; j < 5; ++j) {
        //    printf("Buffer[%d]: %d\r\n", j, (unsigned int) flip(controller1.slave_buffer[j]));
        //}


        /********** SEND DATA TO CARS ********/
        //send_data_to_car(&controller1);
        //send_data_to_car(&controller2);
        //send_data_to_car(&controller3);
        //send_data_to_car(&controller4);

		// Vibration data is updated automagically by interrupts



        /********** EGGIES!!! ***********/

         // EGGIE INITS ///
        //// VERY IMPORTANT EASTER BUG HAPPENS SOMEHOW WITH HEAD AND TURNS OFF CONTROLLER
/*        uint8_t light_show_end=1;
        uint32_t gpio_inputs=0;
*/
/*        head->next=NULL;
        head->type=LIGHTS_OFF;
*/
        list_init();
        /*Current Easter Egg Codes:

		1.	Triangle -> Circle -> X -> Square -> Triangle
		2.	Right -> Down -> Left -> Up -> Right
		3.	
		4.	
         */


//       uint8_t press_seq0[]= {8,9,10,11,8};
        //uint8_t press_seq1[]={4,7,5,6,4};
//        init_easter_eggie(press_seq0,0,5);
        //init_easter_eggie(press_seq1,1,5);
//        easter_eggie(&controller1);
        //easter_eggie(&controller2);
        //easter_eggie(&controller3);
        //easter_eggie(&controller4);
/*        gpio_inputs = MSS_GPIO_get_inputs();

        if(gpio_inputs == 0x10) { //GPIO 4??
            light_show_end=1;
        }

        else {
            light_show_end=0;
        }
*/
        /*while(list not empty && light_show_end
            keep popping off light shows
            and call light_show functions
            light show function gets called in pop
        */

  //     show_t * current = head;
 /*    while((current != NULL) && light_show_end){
			current=current->next;
            pop();
            play();
        }
*/
		/********** CHECK SCORING STATUS **********/


        //set_vibration(&controller1,0xFF);
        //set_vibration(&controller2,0xFF);
		
        /*
		if (controller1.slave_buffer[10] > 0) {
			set_vibration(&controller1, 0xff);
			counter = 0;
		}
		*/
		//*
        //for (j = 0; j < 10000; ++j); // Delay
       // counter++;
        //int x = counter;

        /*
        if (counter > 50) {
        	set_vibration(&controller1, 0);
        	set_vibration(&controller2, 0);
        }
        */
        /*
    	if (!teamMaize.already_scored && !teamBlue.already_scored) {
    		if (ARENA_checkIfScored(&teamMaize)) {
    			teamMaize.already_scored = 1;
    			teamMaize.score += 1;
    			ARENA_outputScoreToScreen(&teamMaize, &teamBlue);

    		}

    		else if (ARENA_checkIfScored(&teamBlue)) {
    			teamBlue.already_scored = 1;
    			teamBlue.score += 1;
    			ARENA_outputScoreToScreen(&teamMaize, &teamBlue);
    		}
    	}
    	else if (teamMaize.already_scored) {
    		if (!ARENA_checkIfScored(&teamMaize)) {
    			teamMaize.already_scored = 0;
    		}
    	}
    	else {
    		if (!ARENA_checkIfScored(&teamBlue)) {
    			teamBlue.already_scored = 0;
    		}
    	}



	*/

    }

    // If you've made it this far, something went wrong
    return(1);
}
