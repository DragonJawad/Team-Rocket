/**************************************\
 * File Name:      main.c
 * Project Name:   EECS 373 Final Project
 * Created by:     Adrian Padin
 * Start date:     15 March 2016
\**************************************/

#include <stdio.h>
#include <inttypes.h>
#include <assert.h>
#include <stdlib.h>

#include "drivers/mss_spi/mss_spi.h"
#include "drivers/mss_uart/mss_uart.h"
#include "drivers/mss_gpio/mss_gpio.h"
#include "drivers/mss_ace/mss_ace.h"
#include "drivers/CoreUARTapb/core_uart_apb.h"
#include "ps2.h"
#include "arena.h"
#include "screenControl.h"
#include "light_show.h"
#include "linked_list.h"
#include "eggie.h"
#include "defines.h"


/********** GLOBAL VARIABLES **********/
extern controller_t controller1;
extern controller_t controller2;
extern controller_t controller3;
extern controller_t controller4;

team_struct_t teamMaize;
team_struct_t teamBlue;

const uint32_t COUNTDOWN_START = 1000 / TIMER_LENGTH;
uint32_t time_remaining = 0; // In seconds
uint32_t timer_countdown = 0;
uint32_t controller_to_poll = 1;


/********** FUNCTION DECLARATIONS **********/
int main();
void xbee_receive_data(mss_uart_instance_t *);
void send_data_to_car(controller_t *);
void stopCars();
void teamScored(int);
void initGame();
void endGame();
void runGame();


/********** INTERRUPT HANDLERS AND HELPERS **********/

// UART RX Interrupt Handler
void xbee_receive_data( mss_uart_instance_t * this_uart ) {

    uint8_t rx_buff[NUM_BYTES_SENT]; // Data received

    // Read in data from rx_buff
	int num_bytes = MSS_UART_get_rx( this_uart, rx_buff, NUM_BYTES_SENT );

	if (num_bytes != NUM_BYTES_SENT) return; // Transmission failed

	int car_select = rx_buff[0];

	// Set the vibration value
	switch (car_select) {
		case 2: set_vibration(&controller1, 0xFF); break;
		case 3: set_vibration(&controller2, 0xFF); break;
		case 4: set_vibration(&controller2, 0xFF); break;
		case 5: set_vibration(&controller2, 0xFF); break;
		default: break;
	}
	
	//printf("Got some XBEE data: car %x, value %x\r\n", car_select, vibration);
}


// Send data to the cars (helper for Fabric IRQ)
void send_data_to_car(controller_t * controller) {

	uint8_t tx_buff[4] = { 	(controller->select + 1),
							flip(controller->data[1]) & 0xfe,
							flip(controller->data[3]) | 0x01,
							0
	};

    MSS_UART_polled_tx(&g_mss_uart1, tx_buff, NUM_BYTES_SENT);
}


// Fabint handler to handle, say, interrupts from fabric to MSS
__attribute__ ((interrupt)) void Fabric_IRQHandler( void )
{
    // Get the interrupt status (which also clears the internal interrupt on our hardware)
    uint32_t status = ARENA_getInterruptStatus();
    //printf("Interrupt status: %u\n\r", (unsigned int) status);

    // Status 2 is a timer interrupt
    // Should receive timer interrupts every 100 ms
    if(status & 0x02) {

    	// Rotate between the four of them
    	if (controller_to_poll == 4) {
    		controller_to_poll = 1;
    	}
    	else {
    		++controller_to_poll;
    	}

    	// Poll the next controller
    	switch (controller_to_poll) {
			case 1:
				digital_capture(&controller1);
				full_capture(&controller1);
				send_data_to_car(&controller1);
				break;
			case 2:
				digital_capture(&controller2);
				full_capture(&controller2);
				send_data_to_car(&controller2);
				break;
			case 3:
				digital_capture(&controller3);
				full_capture(&controller3);
				send_data_to_car(&controller3);
				break;
			case 4:
				digital_capture(&controller4);
				full_capture(&controller4);
				send_data_to_car(&controller4);
				break;
    	}

    	// Check the countdown time: 10 * 100ms = 1 second
    	if (timer_countdown == 0) {

    		timer_countdown = COUNTDOWN_START;	// Reset the countdown

			// Decrement the time remaining - should happen once a second
    		--time_remaining;
			ARENA_outputTimeLeft(time_remaining);

			// If time has run out, game is over
			if(time_remaining == 0) {
				endGame(); // does not return
			}
		} else {
			--timer_countdown; // ITS THE FINAL COUNTDOWN

    	}
	}

    // Button interrupt (not currently hooked up to anything)
    //if (status & 0x01) {
    //}

    NVIC_ClearPendingIRQ( Fabric_IRQn ); // Clear pending interrupt
}


// Stop all cars from moving
void stopCars() {

	// Send a clear message to all cars
	int car_id;
	for (car_id = 2; car_id < 6; ++car_id) {
		uint8_t tx_buff[4] = {car_id, 0x80, 0x81, 0};
		MSS_UART_polled_tx(&g_mss_uart1, tx_buff, 4);
	}

	// Also turn off vibration
	controller1.vibration = 0;
	controller2.vibration = 0;
	controller3.vibration = 0;
	controller4.vibration = 0;
}


// Occurs when a team scores a goal. Team ID is specified by teamScoredFlag
void teamScored(int teamScoredFlag) {

	NVIC_DisableIRQ(Fabric_IRQn);	// Disable the timer interrupt

	stopCars(); // Stop the cars; game should be paused at the moment!

	// Reset all easter egg states
	int i;
	for(i = 0; i < NUM_EASTER_EGGS; i++) { controller1.state[i] = 0; }
	for(i = 0; i < NUM_EASTER_EGGS; i++) { controller2.state[i] = 0; }
	for(i = 0; i < NUM_EASTER_EGGS; i++) { controller3.state[i] = 0; }
	for(i = 0; i < NUM_EASTER_EGGS; i++) { controller4.state[i] = 0; }

	// Increment the team's score and check if they won
	if (teamScoredFlag == BLUE) {
		teamBlue.score++;
		if(teamBlue.score == SCOREMAX) {
			endGame(); // Does not return
		}
		ARENA_outputTeamBlueScored();
	}
	else if (teamScoredFlag == MAIZE) {
		teamMaize.score++;
		if(teamMaize.score == SCOREMAX) {
			endGame(); // Does not return
		}
		ARENA_outputTeamMaizeScored();
	}
	else {
		return; // bad teamScoredFlag
	}

	ARENA_outputScoreToScreen(&teamMaize, &teamBlue); // Output score to screen



	// Team's light show
	wait_lights_end();
	light_show(teamScoredFlag);		// Team's light show
	wait_lights_start();			// Wait for light show to start
	turn_off_lights();				// Turn off all lights
	ARENA_closeBallRelease();		// Prepare the ball release

	// Vibrate all controllers on and off four times
	for (i = 0; i < 4; ++i) {
		set_vibration(&controller1, 0xff);
		set_vibration(&controller2, 0xff);
		set_vibration(&controller3, 0xff);
		set_vibration(&controller4, 0xff);

		poll_delay(50);
		printf("Vibrate\r\n");

		set_vibration(&controller1, 0);
		set_vibration(&controller2, 0);
		set_vibration(&controller3, 0);
		set_vibration(&controller4, 0);

		poll_delay(50);
	}

	wait_lights_end(); // Wait for team's show to end

	runGame(); // Return to the game
}


// All necessary setup to begin the game
void initGame() {

	/********** SETUP SCREEN AND XBEES **********/

	SCREENCONTROL_init();

	// Setup XBee UART
	MSS_UART_init (
		&g_mss_uart1,
		MSS_UART_9600_BAUD,
		(MSS_UART_DATA_8_BITS | MSS_UART_NO_PARITY | MSS_UART_ONE_STOP_BIT)
	);

	// Interrupt handler for incoming XBee data
	MSS_UART_set_rx_handler
	(
		&g_mss_uart1,
		xbee_receive_data,
		MSS_UART_FIFO_FOUR_BYTES
	);

	/********** SETUP LIGHT SHOW **********/

	init_lights();
	init_easter_eggs();

	/********** SETUP TEAMS **********/

	ACE_init();

	ARENA_initTeam(&teamMaize, "ADCDirectInput_4");
	ARENA_initTeam(&teamBlue, "ADCDirectInput_5");

	teamMaize.score = 0;
	teamBlue.score = 0;

	/********** SETUP CONTROLLERS **********/

	MSS_SPI_init( &g_mss_spi1 );

	controller_init(&controller1, MSS_SPI_SLAVE_1);
	controller_init(&controller2, MSS_SPI_SLAVE_2);
	controller_init(&controller3, MSS_SPI_SLAVE_3);
	controller_init(&controller4, MSS_SPI_SLAVE_4);

	setup_all(&controller1);
	setup_all(&controller2);
	setup_all(&controller3);
	setup_all(&controller4);

	/********** SETUP TIMER **********/

	time_remaining = GAMELENGTH;
	timer_countdown = COUNTDOWN_START; // counts down
}


// Finish the game and declare a winner
void endGame() {

	NVIC_DisableIRQ(Fabric_IRQn); 	// Disable the timer interrupts
	//kill_show();
	stopCars(); 					// Stop the cars forever

	int whoWon = 0;

	if(teamBlue.score > teamMaize.score) {
		light_show(BLUE);
		whoWon = BLUE;
	}
	else if(teamMaize.score > teamBlue.score) {
		light_show(MAIZE);
		whoWon = MAIZE;
	}
	else {
		light_show(TIEGAME);
	}

	ARENA_outputEndToScreen(whoWon); // Final screen display

	// Any player can press start to restart the game
	while ( (controller1.digi[0] & ~0xef) != 0 ||
			(controller2.digi[0] & ~0xef) != 0 ||
			(controller3.digi[0] & ~0xef) != 0 ||
			(controller4.digi[0] & ~0xef) != 0) {
		digital_capture(&controller1);
		digital_capture(&controller2);
		digital_capture(&controller3);
		digital_capture(&controller4);
	}

	main();
}


// Normal game play
void runGame() {

	// Run the beginning game sequence

	NVIC_DisableIRQ(Fabric_IRQn); 	// Disable timer
	stopCars(); 					// Hold cars still
	ARENA_closeBallRelease();		// Prepare the ball release
	ARENA_outputScoreToScreen(&teamMaize, &teamBlue); // Output score to screen
	ARENA_outputStartToScreen();	// "Press X to Start"
	buttonWait();					// Wait for all players to press X

	light_show(START); 				// Start game light show
	wait_lights_start();			// Wait for the show to start
	turn_off_lights(); 				// Turn off lights
	ARENA_openBallRelease(); 		// Release the ball
	wait_lights_end(); 				// Wait for show to stop

	ARENA_outputScoreToScreen(&teamMaize, &teamBlue);
	ARENA_outputTimeLeft(time_remaining);

	NVIC_EnableIRQ(Fabric_IRQn);	// Re-enable the timer interrupt

	/********** LOOP **********/

	while(1) {

		printf("MAIN\r\n");

		/********** CAPTURE CONTROLLER DATA ********/

		// Polling controllers and sending data to cars is all done through interrupts
		// Receiving vibration data is also updated automagically by interrupts


		/********** CHECK SCORING **********/

		if (ARENA_checkIfScored(&teamMaize)) {
			teamScored(MAIZE);
		}
		else if (ARENA_checkIfScored(&teamBlue)) {
			teamScored(BLUE);
		}

		/*
		// Debugging
		if (controller1.data[5] > 100 && controller1.data[11] > 100) {
			teamScored(MAIZE);
		}
		if (controller1.data[4] > 100 && controller1.data[9] > 100) {
			teamScored(BLUE);
		}
		*/

		/********** CHECK EASTER EGGS **********/

 		check_easter_eggs(&controller1);
 		check_easter_eggs(&controller2);
 		check_easter_eggs(&controller3);
 		check_easter_eggs(&controller4);

		run_eggies();

	} // end while
}


// Outputs game over stuff and cleans up as necessary
int main() {

	initGame(); // Initialize necessary game systems

	poll_delay(30);

 	ARENA_outputBeginGameToScreen();

	wait_lights_end(); // wait for init light show to stop

	runGame();   // Play the game: Does not return!

    return(0);
}
