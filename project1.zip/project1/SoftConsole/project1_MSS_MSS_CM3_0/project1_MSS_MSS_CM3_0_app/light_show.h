/**************************************\
 * File Name:      light_show.h
 * Project Name:   EECS373 Final Project
 * Created by:     Adrian Padin
 * Start date:     31 March 2016
 * Last modified:  4 April 2016
\**************************************/

#ifndef LIGHT_SHOW_H_
#define LIGHT_SHOW_H_

#include "ps2.h"
#include "defines.h"
#include "drivers/mss_gpio/mss_gpio.h"

// Initialize the light show (run only once)
void init_lights(void);

// Run a specific light show
void light_show(mss_gpio_id_t gpio_id);

// Turn off all lights
void turn_off_lights();

// Wait for the light show to start
void wait_lights_start();

// Wait for the light show to end
void wait_lights_end();

// Stop the show that is currently running immediately
//void kill_show();

#endif
