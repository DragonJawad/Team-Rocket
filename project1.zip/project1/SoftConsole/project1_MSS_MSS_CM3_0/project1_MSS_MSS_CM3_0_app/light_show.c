/**************************************\
 * File Name:      light_show.c
 * Project Name:   EECS373 Final Project
 * Created by:     Adrian Padin
 * Start date:     31 March 2016
 * Last modified:  16 April 2016
\**************************************/

#include "ps2.h"
#include "light_show.h"
#include "linked_list.h"
#include <assert.h>
#include <stdio.h>

uint8_t eggies[NUM_EASTER_EGGS][MAX_EGGIE_LENGTH+1];
uint32_t GPIO_eggie[NUM_EASTER_EGGS];


// Initialize the light show (run only once)
void init_lights(void) {

    MSS_GPIO_init();

	// Initialize all possible light shows as outputs
    MSS_GPIO_config(BLUE, MSS_GPIO_OUTPUT_MODE);
    MSS_GPIO_config(MAIZE, MSS_GPIO_OUTPUT_MODE);
    MSS_GPIO_config(START, MSS_GPIO_OUTPUT_MODE);
    MSS_GPIO_config(TIEGAME, MSS_GPIO_OUTPUT_MODE);
    MSS_GPIO_config(INTERRUPT, MSS_GPIO_OUTPUT_MODE);
    MSS_GPIO_config(EGG1, MSS_GPIO_OUTPUT_MODE);
    MSS_GPIO_config(EGG2, MSS_GPIO_OUTPUT_MODE);
    MSS_GPIO_config(EGG3, MSS_GPIO_OUTPUT_MODE);

	// Initalize return input
    MSS_GPIO_config(MSS_GPIO_8, MSS_GPIO_INPUT_MODE);

    // Start with all lights off
    turn_off_lights();
	MSS_GPIO_set_output(INTERRUPT, 1);
}

// Run a specific light show
void light_show(mss_gpio_id_t gpio_id) {

	// Turn the pin off
    MSS_GPIO_set_output(gpio_id, 0);
}

// Turn off all lights
void turn_off_lights() {
	// All outputs are active low/passive high
	int i;
	for (i = 1; i < NUM_GPIO_PINS; ++i) {
		MSS_GPIO_set_output(i, 1);
	}
}

/*
// Stop the currently running show by throwing an interrupt
void kill_show() {
	turn_off_lights();
	MSS_GPIO_set_output(INTERRUPT, 0);
	printf("Waiting for lights to end\r\n");
	wait_lights_end();
	printf("Lights ended\r\n");
	MSS_GPIO_set_output(INTERRUPT, 1);
}
*/

// Wait for the light show to start
void wait_lights_start() {
	printf("Waiting for ACK\r\n");
	while ((MSS_GPIO_get_inputs() & MSS_GPIO_8_MASK) != 0) { poll_delay(1); }
	printf("ACK went low\r\n");
}

// Wait for the light show to end
void wait_lights_end() {\
	printf("Waiting for ACK\r\n");
	while ((MSS_GPIO_get_inputs() & MSS_GPIO_8_MASK) != MSS_GPIO_8_MASK) { poll_delay(1); }
	printf("ACK went high\r\n");
}



