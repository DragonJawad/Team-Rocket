/*
 * defines.h
 *
 *  Created on: Apr 8, 2016
 *      Author: erowland
 */

#ifndef DEFINES_H_
#define DEFINES_H_

#define OFF 0
#define BLUE 1
#define MAIZE 2
#define START 3
#define EGG1 5
#define EGG2 6
#define EGG3 7
#define EGG4 8

#define COUNT_START 10

#define FULL_BUFFER_SIZE 16

#define MAX_EGGIE_LENGTH 5
#define NUM_GPIO_PINS 10




#define NUM_EASTER_EGGS 1

#endif /* DEFINES_H_ */
