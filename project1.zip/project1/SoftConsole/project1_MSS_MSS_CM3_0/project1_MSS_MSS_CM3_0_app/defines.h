/*
 * defines.h
 *
 *  Created on: Apr 8, 2016
 *      Author: erowland
 */

#ifndef DEFINES_H_
#define DEFINES_H_

#define NUM_EASTER_EGGS 2

#endif /* DEFINES_H_ */
