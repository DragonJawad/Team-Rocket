/*
 * linked_list.h
 *
 *  Created on: Apr 6, 2016
 *      Author: erowland
 */

#ifndef LINKED_LIST_H_
#define LINKED_LIST_H_

#include <inttypes.h>
#include "drivers/mss_gpio/mss_gpio.h"

typedef struct show {
    uint32_t type;
    struct show * next;
} show_t;

void push(show_t * head, uint32_t type);

void pop(show_t * head);

show_t *head;
#endif /* LINKED_LIST_H_ */
