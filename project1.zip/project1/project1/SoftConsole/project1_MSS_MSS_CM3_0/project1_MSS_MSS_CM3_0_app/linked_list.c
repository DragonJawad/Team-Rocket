/*
 * linked_list.c
 *
 *  Created on: Apr 6, 2016
 *      Author: erowland
 */
#include "linked_list.h"
#include "light_show.h"
#include <assert.h>
#include <stdlib.h>
#include "drivers/mss_gpio/mss_gpio.h"

// Adds to end of list
void push(show_t * head, uint32_t type) {
    show_t * current = head;
    while (current->next != NULL) {
        current = current->next;
    }
    current->next = malloc(sizeof(show_t));
    current->next->type = type;
    current->next->next = NULL;
}

//Remove first in list
void pop(show_t * head){
	assert(head != NULL);
	show_t * temp = head;
	head = head->next;
	free(head);
	light_show(temp->type);
    MSS_GPIO_set_output(temp->type, 1);
}
